import 'package:flutter/material.dart';

class Lab_15_2 extends StatelessWidget {

  //List which we are going to display
  List<int> numbers = [1,2,3,4,5,6,7];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView.builder(
        itemCount: numbers.length,
        itemBuilder: (context, index) => ListTile(title: Text(numbers[index].toString()),),
      ),
    );
  }
}
