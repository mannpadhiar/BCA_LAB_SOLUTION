import 'package:flutter/material.dart';

class Lab_15_1 extends StatelessWidget {

  //List which we are going to display
  List<int> numbers = [1,2,3,4,5,6,7];
  int i = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      body: ListView(
        children: [
          ListTile(
            title: Text(numbers[0].toString()),
          ),
          ListTile(
            title: Text(numbers[1].toString()),
          ),
          ListTile(
            title: Text(numbers[2].toString()),
          ),ListTile(
            title: Text(numbers[3].toString()),
          ),ListTile(
            title: Text(numbers[4].toString()),
          ),ListTile(
            title: Text(numbers[5].toString()),
          ),ListTile(
            title: Text(numbers[6].toString()),
          ),
        ],
      ),
    );
  }
}
